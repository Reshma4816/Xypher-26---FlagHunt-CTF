Writeup
Step 1 — Initial Enumeration

Run common checks:

file ghost_rows.png
strings ghost_rows.png
exiftool ghost_rows.png
binwalk ghost_rows.png
Observation

Metadata contains:
CTF{n0t_th15_0n3}
This appears to be a flag, but it is intentionally fake.
No useful appended archives or embedded files are found.

Step 2 — Visual Inspection
Opening the image shows:

White background
Grid pattern
Text:
ARCHIVE RESTORED
Nothing visually suspicious.

Step 3 — Understand the Challenge Name

Challenge title:
Ghost Rows
This strongly suggests that hidden data exists inside specific rows of the image.

The archive clue:
Rows remember what eyes forget.
So row-based extraction is likely intended.

Step 4 — Determine Extraction Pattern
The hidden payload was embedded using:

Every 17th row
Alternate rows reversed
Green channel LSB bits
XOR encrypted

Need custom extraction.

Step 5 — Extract Hidden Bits
Use Python:

from PIL import Image
img = Image.open("ghost_rows.png").convert("RGB")
pix = img.load()
bits = []
for y in range(0, img.height, 17):
    xs = list(range(img.width))

    # Reverse alternate rows
    if (y // 17) % 2 == 1:
        xs.reverse()

    for x in xs:
        r,g,b = pix[x,y]
        bits.append(str(g & 1))

# Convert bits to bytes
data = bytearray()
for i in range(0, len(bits), 8):
    byte = bits[i:i+8]
    if len(byte) < 8:
        break
    data.append(int("".join(byte),2))
print(data[:100])

Step 6 — XOR Decrypt Payload
The challenge theme hints at shadows / hidden layers.

Correct XOR key:
shade

Decrypt:
key = b"shade"
out = bytearray()
for i,b in enumerate(data):
    out.append(b ^ key[i % len(key)])
print(out.decode(errors="ignore"))

Final Output
CTF{r0w5_n3v3r_l13_1f_c4r3fu11y_in5p3ct3d}
