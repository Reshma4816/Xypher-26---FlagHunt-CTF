Writeup
Step 1 — Initial Enumeration

Run standard checks:

file museum.png
strings museum.png
exiftool museum.png
binwalk museum.png
Observation

The image opens normally as a museum/gallery photo.

However, binwalk reveals additional embedded data after the PNG structure.

Example:

ZIP archive data found ...

This suggests the file is a polyglot-style challenge: a valid image with hidden content appended.

Step 2 — Extract Hidden Archive

Use:

binwalk -e museum.png

or manually carve/unzip the hidden archive.

Recovered files:

qr_a.png
qr_b.png
qr_c.png
poster.png
note.txt
Step 3 — Inspect Extracted Files
poster.png

Contains a visible QR code.

Scanning it gives a misleading message such as:

Reflection lies.

This is a decoy intended to waste time.

note.txt

Contains:

Truth survives only when aligned.

This indicates the real path involves arranging fragments correctly.

Step 4 — Analyze QR Fragments

Files:

qr_a.png
qr_b.png
qr_c.png

These are damaged parts of the real QR code.

Each fragment was intentionally altered:

qr_a.png rotated
qr_b.png mirrored horizontally
qr_c.png low contrast / missing border
Step 5 — Repair Each Fragment
Fix A (rotate back)
convert qr_a.png -rotate 270 fixed_a.png
Fix B (unmirror)
convert qr_b.png -flop fixed_b.png
Fix C (restore contrast)
convert qr_c.png -brightness-contrast 60x60 fixed_c.png

If needed, add border:

convert fixed_c.png -bordercolor white -border 10 fixed_c.png

Step 6 — Reconstruct the QR Code
Join horizontally:
convert +append fixed_a.png fixed_b.png fixed_c.png repaired.png

If scanning fails, add quiet zone border:
convert repaired.png -bordercolor white -border 20 repaired2.png

Step 7 — Scan Final QR
Use phone scanner or:
zbarimg repaired2.png

Final Output
CTF{br0k3n_th1ng5_5t1ll_t3ll_tru7h}
