Writeup
Step 1 — Initial Enumeration

Run common checks:

file dead_pixels.png
strings dead_pixels.png
exiftool dead_pixels.png
binwalk dead_pixels.png
Observation

Image opens normally and appears like a damaged monitor with vertical noise bars and text:
SCREEN FAILURE
No appended ZIP or obvious hidden chunks.
But metadata comment contains:
676c69746368

Step 2 — Decode Metadata Value
Looks like hex.

Use Python:
python3 -c 'print(bytes.fromhex("676c69746368").decode())'

Output:
glitch

Likely encryption/decryption key.

Step 3 — Understand Challenge Name
Title:
Dead Pixels
This strongly suggests hidden data stored in image pixels.
Need inspect pixel values.

Step 4 — Notice Possible Prime Pattern
Since normal LSB scans fail, challenge likely uses structured pixel selection.
Try prime-numbered columns.

Step 5 — Extract Bits from Prime Columns
Also based on challenge design:

Read rows bottom to top
Reverse every third row
Use Blue channel LSB

Use this solver:

from PIL import Image
import math

img = Image.open("dead_pixels.png").convert("RGB")
pix = img.load()

def isprime(n):
    if n < 2:
        return False
    for i in range(2, int(n**0.5)+1):
        if n % i == 0:
            return False
    return True

bits = []

for y in reversed(range(img.height)):

    cols = [x for x in range(img.width) if isprime(x)]

    if y % 3 == 0:
        cols.reverse()

    for x in cols:
        r,g,b = pix[x,y]
        bits.append(str(b & 1))

# convert bits to bytes
data = bytearray()

for i in range(0, len(bits), 8):
    byte = bits[i:i+8]
    if len(byte) < 8:
        break
    data.append(int("".join(byte),2))

print(data[:100])

Step 6 — XOR Decrypt Using Key
Now decrypt extracted bytes using recovered key:

enc = data
key = b"glitch"

out = bytearray()

for i,b in enumerate(enc):
    out.append(b ^ key[i % len(key)])

print(out[:100])

Output resembles Base64 text.

Step 7 — Base64 Decode
import base64

decoded = base64.b64decode(out)
print(decoded.decode())

Final Output
CTF{d34d_p1x3l5_5t1ll_5p34k}
