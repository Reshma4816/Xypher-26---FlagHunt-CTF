Writeup

Final Flag
CTF{sp3ctr0_gr4m_s3cr3ts_r3v3al3d}

Step 1 — Inspect the Audio File
The challenge provides:
echoes.wav
Listening normally reveals only static/noise.
This suggests hidden data may exist visually inside the waveform.

Step 2 — Open in Spectrogram Mode
Use Audacity or any audio analysis tool.

In Audacity:
Open echoes.wav
Click track dropdown
Select Spectrogram

Hidden text appears:
CTF{m4yb3_s3v3n!}

Step 3 — Analyze the Clues
These are fake flags, but also hints:
Hint
CTF{m4yb3_s3v3n!}

Meaning:
The number 7 is likely important.

Step 4 — Inspect the File Structure
Use:
strings echoes.wav
You may see mostly random data.

Use:
xxd echoes.wav | tail
or:
binwalk echoes.wav

This reveals extra appended bytes after the WAV audio data.
Those bytes are an encrypted payload.

Step 5 — Extract Appended Payload
Extract the hidden tail manually or via script.
Example:
tail -c 700 echoes.wav > hidden.bin

(Exact size depends on challenge build.)

Step 6 — XOR Decrypt Using Key 7
The spectrogram hint suggested seven.

Use Python:
data = open("hidden.bin","rb").read()
dec = bytes([b ^ 7 for b in data])
open("decoded.bin","wb").write(dec)

This produces a readable payload.

Step 7 — Recognize Brainfuck Code
Opening decoded.bin reveals Brainfuck symbols such as:
+++++[>++++<-]>...
This is Brainfuck, an esoteric programming language.

Step 8 — Decode Brainfuck
Use any Brainfuck interpreter online or locally.
Running the decoded Brainfuck outputs:

CTF{sp3ctr0_gr4m_s3cr3ts_r3v3al3d}
